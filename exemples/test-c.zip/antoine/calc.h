#ifndef CALC_H 
#define CALC_H

int add(int, int);
int sub(int, int);
int mul(int, int);
float divide(int, int);
int max(int, int);
char* concat(const char*, const char*);

#endif
